package com.sample.dao;

import com.sample.entities.BiddingEntity;
import com.sample.entities.JobEntity;
import com.sample.entities.TruckType;

import java.util.Arrays;
import java.util.List;

public class JobDao {
    public static List<JobEntity> getJobsByShipperId(String shipperId) {
        JobEntity jobEntity1 = new JobEntity("J1", shipperId, "Job1", "Jakarta", "Tangerang", 56771671L, 1000000);
        JobEntity jobEntity2 = new JobEntity("J2", shipperId, "Job2", "Bandung", "Boyor", 56771674L, 900000);
        JobEntity jobEntity3 = new JobEntity("J3", shipperId, "Job3", "Bali", "Cipubar", 56771673L, 1200000);
        JobEntity jobEntity4 = new JobEntity("J4", shipperId, "Job4", "Surabaya", "Depole", 56771676L, 800000);
        JobEntity jobEntity5 = new JobEntity("J5", shipperId, "Job5", "Boyor", "Tangerang", 56771678L, 1400000);
        JobEntity jobEntity6 = new JobEntity("J6", shipperId, "Job6", "Bandung", "Jakarta", 56771677L, 1200000);
        JobEntity jobEntity7 = new JobEntity("J7", shipperId, "Job7", "Bandung", "Tangerang", 56771679L, 1150000);
        JobEntity jobEntity8 = new JobEntity("J8", shipperId, "Job8", "Bali", "Depole", 56771670L, 1700000);

        return Arrays.asList(jobEntity1, jobEntity2, jobEntity3, jobEntity4, jobEntity5, jobEntity6, jobEntity7, jobEntity8);
    }

    public static List<JobEntity> getJobsByTransporterId() {
        JobEntity jobEntity1 = new JobEntity("J1", "S1", "Job1", "Jakarta", "Tangerang", 56771671L, 1000000);
        JobEntity jobEntity2 = new JobEntity("J2", "S1", "Job2", "Bandung", "Boyor", 56771674L, 900000);
        JobEntity jobEntity3 = new JobEntity("J3", "S1", "Job3", "Bali", "Cipubar", 56771673L, 1200000);
        JobEntity jobEntity4 = new JobEntity("J4", "S1", "Job4", "Surabaya", "Depole", 56771676L, 800000);
        JobEntity jobEntity5 = new JobEntity("J5", "S1", "Job5", "Boyor", "Tangerang", 56771678L, 1400000);
        JobEntity jobEntity6 = new JobEntity("J6", "S1", "Job6", "Bandung", "Jakarta", 56771677L, 1200000);
        JobEntity jobEntity7 = new JobEntity("J7", "S1", "Job7", "Bandung", "Tangerang", 56771679L, 1150000);
        JobEntity jobEntity8 = new JobEntity("J8", "S1", "Job8", "Bali", "Depole", 56771670L, 1700000);

        return Arrays.asList(jobEntity1, jobEntity2, jobEntity3, jobEntity4, jobEntity5, jobEntity6, jobEntity7, jobEntity8);
    }

    public static List<BiddingEntity> getBiddingEntitiesByTransporterId(String transportedId) {
        BiddingEntity biddingEntity1 = new BiddingEntity("B1", transportedId, "J1", TruckType.Tronton.name(), 1200000);
        BiddingEntity biddingEntity2 = new BiddingEntity("B2", transportedId, "J2", TruckType.CDD.name(), 800000);
        BiddingEntity biddingEntity3 = new BiddingEntity("B3", transportedId, "J3", TruckType.Wingbox.name(), 900000);
        BiddingEntity biddingEntity4 = new BiddingEntity("B4", transportedId, "J4", TruckType.Wingbox.name(), 1000000);
        BiddingEntity biddingEntity5 = new BiddingEntity("B5", transportedId, "J5", TruckType.CDD.name(), 1300000);
        BiddingEntity biddingEntity6 = new BiddingEntity("B6", transportedId, "J6", TruckType.Wingbox.name(), 1500000);
        BiddingEntity biddingEntity7 = new BiddingEntity("B7", transportedId, "J7", TruckType.Tronton.name(), 1450000);
        BiddingEntity biddingEntity8 = new BiddingEntity("B8", transportedId, "J8", TruckType.Tronton.name(), 1988000);

        return Arrays.asList(biddingEntity1, biddingEntity2, biddingEntity3, biddingEntity4, biddingEntity5, biddingEntity6, biddingEntity7, biddingEntity8);
    }
}
