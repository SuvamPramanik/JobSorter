package com.sample.service;

import java.util.Comparator;
import java.util.List;

public class Sorter<T> {
    public void sortEntities(List<T> entities, Comparator<T> comparator) {
        for (int i=0; i<entities.size(); i++) {
            for (int j=0; j<entities.size()-i-1; j++) {
                if (comparator.compare(entities.get(j), entities.get(j+1)) > 0) {
                    T temp = entities.get(j);
                    entities.set(j, entities.get(j+1));
                    entities.set(j+1, temp);
                }
            }
        }
    }
}
