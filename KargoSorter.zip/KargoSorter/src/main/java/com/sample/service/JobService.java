package com.sample.service;

import com.sample.dao.JobDao;
import com.sample.entities.*;

import java.util.List;

public class JobService {
    public List<JobEntity> getSortedJobEntities(String id, ViewType viewType, JobSortType jobSortType) throws IllegalAccessException {
        List<JobEntity> jobEntities;
        if (viewType == ViewType.SHIPPER) {
            jobEntities = JobDao.getJobsByShipperId(id);
        } else if (viewType == ViewType.TRANSPORTER) {
            jobEntities = JobDao.getJobsByTransporterId();
        } else {
            throw new IllegalAccessException("viewType is invalid!!");
        }
        Sorter<JobEntity> sorter = new Sorter<>();
        sorter.sortEntities(jobEntities, jobSortType.getJobEntityComparator());
        return jobEntities;
    }

    public List<BiddingEntity> getSortedBiddingEntities(String id, BiddingSortType biddingSortType) {
        List<BiddingEntity> biddingEntities = JobDao.getBiddingEntitiesByTransporterId(id);
        Sorter<BiddingEntity> sorter = new Sorter<>();
        sorter.sortEntities(biddingEntities, biddingSortType.getComparator());
        return biddingEntities;
    }
}
