package com.sample;

import io.dropwizard.Application;
import io.dropwizard.Configuration;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;

public class SorterApplication extends Application<CustomConfiguration> {
    public static void main(String[] args) throws Exception {
        new SorterApplication().run(args);
    }

    @Override
    public String getName() {
        return "sorter-application";
    }

    @Override
    public void initialize(Bootstrap<CustomConfiguration> bootstrap) {
        // nothing to do yet
    }

    @Override
    public void run(CustomConfiguration configuration,
                    Environment environment) {
        final SorterResource resource = new SorterResource();
        environment.jersey().register(resource);
    }
}