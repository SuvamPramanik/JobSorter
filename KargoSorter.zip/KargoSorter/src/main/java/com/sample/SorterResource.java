package com.sample;

import com.sample.entities.*;
import com.sample.service.JobService;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/")
@Produces(MediaType.APPLICATION_JSON)
public class SorterResource {

    @GET
    @Path("jobs")
    public List<JobEntity> getSortedJobEntities(@QueryParam("id") String id,
                                    @QueryParam("sortBy") JobSortType jobSortType,
                                    @QueryParam("viewType") ViewType viewType) throws IllegalAccessException {
        JobService jobService = new JobService();
        return jobService.getSortedJobEntities(id, viewType, jobSortType);
    }

    @GET
    @Path("bidding/jobs")
    public List<BiddingEntity> getSortedBiddingEntities(@QueryParam("transporterId") String transportedId,
                                                        @QueryParam("sortBy")BiddingSortType biddingSortType) {
        JobService jobService = new JobService();
        return jobService.getSortedBiddingEntities(transportedId, biddingSortType);
    }
}