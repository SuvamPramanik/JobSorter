package com.sample;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.dropwizard.Configuration;
import org.checkerframework.checker.nullness.qual.NonNull;

import javax.annotation.Nullable;

public class CustomConfiguration extends Configuration {
    @NonNull
    private String defaultName = "Suvam";

    @JsonProperty
    public String getDefaultName() {
        return defaultName;
    }

    @JsonProperty
    public void setDefaultName(String defaultName) {
        this.defaultName = defaultName;
    }
}
