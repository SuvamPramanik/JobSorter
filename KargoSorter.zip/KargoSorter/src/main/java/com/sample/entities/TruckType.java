package com.sample.entities;

public enum TruckType {
    Tronton(1),
    Wingbox(2),
    CDD(3);

    private int priority;

    TruckType(int priority) {
        this.priority = priority;
    }

    public int getPriority() {
        return priority;
    }
}
