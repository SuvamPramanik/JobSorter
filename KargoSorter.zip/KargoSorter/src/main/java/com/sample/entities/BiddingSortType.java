package com.sample.entities;

import java.util.Comparator;

public enum BiddingSortType {
    TRUCK_TYPE(BiddingEntity.BiddingComparatorByTruckType),
    AMOUNT(BiddingEntity.BiddingComparatorByBiddingAmount);

    private Comparator<BiddingEntity> comparator;

    BiddingSortType(Comparator<BiddingEntity> comparator) {
        this.comparator = comparator;
    }

    public Comparator<BiddingEntity> getComparator() {
        return comparator;
    }
}
