package com.sample.entities;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.util.Comparator;
import java.util.Objects;

public class JobEntity {
    private String jobId;
    private String shipperId;
    private String jobName;
    private String origin;
    private String destination;
    private long shipmentDate;
    private double shipmentPrice;

    public JobEntity(String jobId, String shipperId, String jobName, String origin, String destination, long shipmentDate, double shipmentPrice) {
        this.jobId = jobId;
        this.shipperId = shipperId;
        this.jobName = jobName;
        this.origin = origin;
        this.destination = destination;
        this.shipmentDate = shipmentDate;
        this.shipmentPrice = shipmentPrice;
    }


    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getShipperId() {
        return shipperId;
    }

    public void setShipperId(String shipperId) {
        this.shipperId = shipperId;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public long getShipmentDate() {
        return shipmentDate;
    }

    public void setShipmentDate(long shipmentDate) {
        this.shipmentDate = shipmentDate;
    }

    public double getShipmentPrice() {
        return shipmentPrice;
    }

    public void setShipmentPrice(double shipmentPrice) {
        this.shipmentPrice = shipmentPrice;
    }

    public static Comparator<JobEntity> JobComparatorByOrigin
            = new Comparator<JobEntity>() {

        public int compare(JobEntity jobEntity1, JobEntity jobEntity2) {
            return jobEntity1.getOrigin().compareTo(jobEntity2.getOrigin());
        }
    };

    public static Comparator<JobEntity> JobComparatorByDestination
            = new Comparator<JobEntity>() {

        public int compare(JobEntity jobEntity1, JobEntity jobEntity2) {
            return jobEntity1.getDestination().compareTo(jobEntity2.getDestination());
        }
    };

    public static Comparator<JobEntity> JobComparatorByShipmentDate
            = new Comparator<JobEntity>() {

        public int compare(JobEntity jobEntity1, JobEntity jobEntity2) {
            if (jobEntity1.getShipmentDate() > jobEntity2.getShipmentDate()) {
                return 1;
            } else if (jobEntity1.getShipmentDate() == jobEntity2.getShipmentDate()) {
                return 0;
            }
            return -1;
        }
    };

    public static Comparator<JobEntity> JobComparatorByShipmentPrice
            = new Comparator<JobEntity>() {

        public int compare(JobEntity jobEntity1, JobEntity jobEntity2) {
            if (jobEntity1.getShipmentPrice() > jobEntity2.getShipmentPrice()) {
                return 1;
            } else if (jobEntity1.getShipmentPrice() == jobEntity2.getShipmentPrice()) {
                return 0;
            }
            return -1;
        }
    };

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        JobEntity jobEntity = (JobEntity) o;

        return new EqualsBuilder()
                .append(shipmentDate, jobEntity.shipmentDate)
                .append(shipmentPrice, jobEntity.shipmentPrice)
                .append(jobId, jobEntity.jobId)
                .append(shipperId, jobEntity.shipperId)
                .append(jobName, jobEntity.jobName)
                .append(origin, jobEntity.origin)
                .append(destination, jobEntity.destination)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(jobId)
                .append(shipperId)
                .append(jobName)
                .append(origin)
                .append(destination)
                .append(shipmentDate)
                .append(shipmentPrice)
                .toHashCode();
    }

    @Override
    public String toString() {
        return "JobEntity{" +
                "jobId='" + jobId + '\'' +
                ", shipperId='" + shipperId + '\'' +
                ", jobName='" + jobName + '\'' +
                ", origin='" + origin + '\'' +
                ", destination='" + destination + '\'' +
                ", shipmentDate=" + shipmentDate +
                ", shipmentPrice=" + shipmentPrice +
                '}';
    }
}
