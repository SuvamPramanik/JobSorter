package com.sample.entities;

public enum ViewType {
    SHIPPER,
    TRANSPORTER
}
