package com.sample.entities;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.util.Comparator;

public class BiddingEntity {
    private String biddingId;
    private String transporterId;
    private String jobId;
    private TruckType truckType;
    private double price;

    public BiddingEntity(String biddingId, String transporterId, String jobId, String truckType, double price) {
        this.biddingId = biddingId;
        this.transporterId = transporterId;
        this.jobId = jobId;
        this.truckType = TruckType.valueOf(truckType);
        this.price = price;
    }

    public String getBiddingId() {
        return biddingId;
    }

    public void setBiddingId(String biddingId) {
        this.biddingId = biddingId;
    }

    public String getTransporterId() {
        return transporterId;
    }

    public void setTransporterId(String transporterId) {
        this.transporterId = transporterId;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public TruckType getTruckType() {
        return truckType;
    }

    public void setTruckType(TruckType truckType) {
        this.truckType = truckType;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public static Comparator<BiddingEntity> BiddingComparatorByTruckType
            = new Comparator<BiddingEntity>() {

        @Override
        public int compare(BiddingEntity biddingEntity1, BiddingEntity biddingEntity2) {
            if (biddingEntity1.getTruckType().getPriority() > biddingEntity2.getTruckType().getPriority()) {
                return 1;
            } else if (biddingEntity1.getTruckType().getPriority() < biddingEntity2.getTruckType().getPriority()) {
                return -1;
            }
            return 0;
        }
    };

    public static Comparator<BiddingEntity> BiddingComparatorByBiddingAmount
            = new Comparator<BiddingEntity>() {

        @Override
        public int compare(BiddingEntity biddingEntity1, BiddingEntity biddingEntity2) {
            if (biddingEntity1.getPrice() > biddingEntity2.getPrice()) {
                return 1;
            } else if (biddingEntity1.getPrice() < biddingEntity2.getPrice()) {
                return -1;
            }
            return 0;
        }
    };

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        BiddingEntity that = (BiddingEntity) o;

        return new EqualsBuilder()
                .append(price, that.price)
                .append(biddingId, that.biddingId)
                .append(transporterId, that.transporterId)
                .append(jobId, that.jobId)
                .append(truckType, that.truckType)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(biddingId)
                .append(transporterId)
                .append(jobId)
                .append(truckType)
                .append(price)
                .toHashCode();
    }

    @Override
    public String toString() {
        return "BiddingEntity{" +
                "biddingId='" + biddingId + '\'' +
                ", transporterId='" + transporterId + '\'' +
                ", jobId='" + jobId + '\'' +
                ", truckType=" + truckType +
                ", price=" + price +
                '}';
    }
}
