package com.sample.entities;

import java.util.Comparator;

public enum JobSortType {
    ORIGIN(JobEntity.JobComparatorByOrigin),
    DESTINATION(JobEntity.JobComparatorByDestination),
    SHIPMENT_DATE(JobEntity.JobComparatorByShipmentDate),
    AMOUNT(JobEntity.JobComparatorByShipmentPrice);

    private Comparator<JobEntity> jobEntityComparator;

    public Comparator<JobEntity> getJobEntityComparator() {
        return jobEntityComparator;
    }

    JobSortType(Comparator<JobEntity> jobEntityComparator) {
        this.jobEntityComparator = jobEntityComparator;
    }
}
