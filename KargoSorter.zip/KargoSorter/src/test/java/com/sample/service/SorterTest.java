package com.sample.service;

import com.sample.dao.JobDao;
import com.sample.entities.JobEntity;
import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class SorterTest {
    @Test
    public void testSortEntities() {
        String shipperId = "S1";
        JobEntity jobEntity1 = new JobEntity("J1", shipperId, "Job1", "Jakarta", "Tangerang", 56771671L, 1000000);
        JobEntity jobEntity2 = new JobEntity("J2", shipperId, "Job2", "Bandung", "Boyor", 56771674L, 900000);
        JobEntity jobEntity3 = new JobEntity("J3", shipperId, "Job3", "Bali", "Cipubar", 56771673L, 1200000);
        JobEntity jobEntity4 = new JobEntity("J4", shipperId, "Job4", "Surabaya", "Depole", 56771676L, 800000);
        JobEntity jobEntity5 = new JobEntity("J5", shipperId, "Job5", "Boyor", "Tangerang", 56771678L, 1400000);
        JobEntity jobEntity6 = new JobEntity("J6", shipperId, "Job6", "Bandung", "Jakarta", 56771677L, 1200000);
        JobEntity jobEntity7 = new JobEntity("J7", shipperId, "Job7", "Bandung", "Tangerang", 56771679L, 1150000);
        JobEntity jobEntity8 = new JobEntity("J8", shipperId, "Job8", "Bali", "Depole", 56771670L, 1700000);

        List<JobEntity> expectedJobEntitiesSortedByOrigin = Arrays.asList(jobEntity3, jobEntity8, jobEntity2, jobEntity6, jobEntity7, jobEntity5, jobEntity1, jobEntity4);
        List<JobEntity> actualJobEntitiesToBeSortedByOrigin = JobDao.getJobsByShipperId(shipperId);
        Sorter<JobEntity> sorter = new Sorter<>();
        sorter.sortEntities(actualJobEntitiesToBeSortedByOrigin, JobEntity.JobComparatorByOrigin);
        Assert.assertEquals(expectedJobEntitiesSortedByOrigin, actualJobEntitiesToBeSortedByOrigin);
    }
}