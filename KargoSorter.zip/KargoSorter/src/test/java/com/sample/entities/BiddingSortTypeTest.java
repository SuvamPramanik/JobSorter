package com.sample.entities;

import org.junit.Assert;
import org.junit.Test;

public class BiddingSortTypeTest {
    @Test
    public void testBiddingComparatorForAmount() {
        Assert.assertEquals(BiddingEntity.BiddingComparatorByBiddingAmount, BiddingSortType.AMOUNT.getComparator());
    }

    @Test
    public void testBiddingComparatorForTruckType() {
        Assert.assertEquals(BiddingEntity.BiddingComparatorByTruckType, BiddingSortType.TRUCK_TYPE.getComparator());
    }
}