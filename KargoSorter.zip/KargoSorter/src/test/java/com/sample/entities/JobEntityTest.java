package com.sample.entities;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Comparator;

public class JobEntityTest {
    Comparator<JobEntity> comparator;
    JobEntity jobEntity1, jobEntity2;

    @Before
    public void setUp() {
        jobEntity1 = new JobEntity("J1", "S1", "Job1", "ORIGIN1", "DESTINATION1", 12345L, 100000);
        jobEntity2 = new JobEntity("J2", "S2", "Job2", "ORIGIN2", "DESTINATION2", 687612L, 80000);
    }

    @Test
    public void testJobComparatorByOrigin () {
        comparator = JobEntity.JobComparatorByOrigin;
        Assert.assertEquals(1, comparator.compare(jobEntity2, jobEntity1));
    }

    @Test
    public void testJobComparatorByDestination () {
        comparator = JobEntity.JobComparatorByDestination;
        Assert.assertEquals(1, comparator.compare(jobEntity2, jobEntity1));
    }

    @Test
    public void testJobComparatorByShipmentDate () {
        comparator = JobEntity.JobComparatorByShipmentDate;
        Assert.assertEquals(1, comparator.compare(jobEntity2, jobEntity1));
    }

    @Test
    public void testJobComparatorByShipmentPrice () {
        comparator = JobEntity.JobComparatorByShipmentPrice;
        Assert.assertEquals(1, comparator.compare(jobEntity1, jobEntity2));
    }
}
