package com.sample.entities;

import org.junit.Assert;
import org.junit.Test;

public class TruckTypeTest {
    @Test
    public void testPriorityForTronTon() {
        Assert.assertEquals(1, TruckType.Tronton.getPriority());
    }

    @Test
    public void testPriorityForWingbox() {
        Assert.assertEquals(2, TruckType.Wingbox.getPriority());
    }

    @Test
    public void testPriorityForCDD() {
        Assert.assertEquals(3, TruckType.CDD.getPriority());
    }
}