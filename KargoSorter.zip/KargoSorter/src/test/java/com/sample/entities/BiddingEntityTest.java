package com.sample.entities;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Comparator;

public class BiddingEntityTest {

    Comparator<BiddingEntity> comparator;
    BiddingEntity biddingEntity1, biddingEntity2, biddingEntity3;

    @Before
    public void setUp() {
        biddingEntity1 = new BiddingEntity("B1", "T1", "J1", TruckType.Tronton.name(), 1234);
        biddingEntity2 = new BiddingEntity("B1", "T1", "J1", TruckType.CDD.name(), 4564);
        biddingEntity3 = new BiddingEntity("B1", "T1", "J1", TruckType.Tronton.name(), 1234);
    }

    @Test
    public void testBiddingComparatorByTruckType1() {
        comparator = BiddingEntity.BiddingComparatorByTruckType;
        Assert.assertEquals(-1, comparator.compare(biddingEntity1, biddingEntity2));
    }

    @Test
    public void testBiddingComparatorByTruckType2() {
        comparator = BiddingEntity.BiddingComparatorByTruckType;
        Assert.assertEquals(0,comparator.compare(biddingEntity1, biddingEntity3));
    }

    @Test
    public void testBiddingComparatorByAmount1() {
        comparator = BiddingEntity.BiddingComparatorByBiddingAmount;
        Assert.assertEquals(1, comparator.compare(biddingEntity2, biddingEntity1));
    }

    @Test
    public void testBiddingComparatorByAmount2() {
        comparator = BiddingEntity.BiddingComparatorByBiddingAmount;
        Assert.assertEquals(0, comparator.compare(biddingEntity1, biddingEntity3));
    }
}