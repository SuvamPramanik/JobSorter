package com.sample.entities;

import org.junit.Assert;
import org.junit.Test;

public class JobSortTypeTest {
    @Test
    public void testJobEntityComparatorForOrigin() {
        Assert.assertEquals(JobEntity.JobComparatorByOrigin, JobSortType.ORIGIN.getJobEntityComparator());
    }

    @Test
    public void testJobEntityComparatorForDestination() {
        Assert.assertEquals(JobEntity.JobComparatorByDestination, JobSortType.DESTINATION.getJobEntityComparator());
    }

    @Test
    public void testJobEntityComparatorForShipmentDate() {
        Assert.assertEquals(JobEntity.JobComparatorByShipmentDate, JobSortType.SHIPMENT_DATE.getJobEntityComparator());
    }

    @Test
    public void testJobEntityComparatorForShipmentPrice() {
        Assert.assertEquals(JobEntity.JobComparatorByShipmentPrice, JobSortType.AMOUNT.getJobEntityComparator());
    }
}